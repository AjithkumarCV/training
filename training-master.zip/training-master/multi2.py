
m=1
for i in range(1, 11):#multiply
	for y in range(1, 11, ):#multiplied by
		print '%d * %d = %d' %(i, m, m*i)
	print 'completed'
