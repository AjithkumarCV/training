truth=('Fullcontact')
#print truth[0:4]
print truth[0:-3]
