truth='Harivaishnav'
print truth[: :5 ]
