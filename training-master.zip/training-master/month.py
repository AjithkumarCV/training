months = ['jan', 'feb', 'march', 'april']
for i in months:
	print i
