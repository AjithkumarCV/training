m = 2
for i in range(1, 11):
	print '%d * %d = %d' %(m, i, m*i)
