limit= input('enter the limit')
start = 1
while (start<=limit):
	print 'its natural number'
	break
