name= "Harivaishnav"
for i in name:
	print i
