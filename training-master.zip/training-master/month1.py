months = ['jan', 'feb', 'march', 'april']
months.append ('may') # to add months
months.append ('july')
print 'adding may and july'
#print months
#print 'missing june'
months.insert (5,'june' )
#print 'current list is', months
#print 'index of month',months[4]
months.remove('feb') #for removing
#print months
print 'sorting months'
months.sort() #sorting
print months
