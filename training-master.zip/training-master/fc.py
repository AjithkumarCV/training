name= 'fullcontact'

for i in name:
	if name ==c :
	print c exists
